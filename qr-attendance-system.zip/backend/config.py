SQLALCHEMY_DATABASE_URI = 'sqlite:///attendance.db'
