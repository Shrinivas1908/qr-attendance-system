## API Endpoints

### POST /mark_attendance
Marks attendance for a student.
- Request: `{ "student_id": 1 }`
- Response: `{ "message": "Attendance marked successfully!" }`