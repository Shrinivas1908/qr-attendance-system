# QR Code Attendance System

A simple QR code-based attendance system built with Flask and HTML5 QR scanner.